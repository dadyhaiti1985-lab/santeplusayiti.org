# Sante Plus Ayiti - Server

1) Install

```bash
cd "/Users/macbook/Desktop/sante plus ayiti"
npm install
```

2) Configure

```bash
cp .env.example .env
# set PAYPAL_ACCESS_TOKEN in .env
```

3) Run

```bash
npm run start
# or for dev:
npm run dev
```

Endpoints:
- POST /api/create-order
- POST /api/capture-order/:orderID

## Business Development Agent

Run daily lead generation and outreach:

```bash
npm run business
```

Requires:
- `GOOGLE_API_KEY` and `GOOGLE_CX` for search
- OpenAI, Twilio, SendGrid keys

Generates `leads-database.json` and `daily-report.txt`.

## Deploy to Netlify (Static Frontend)

1. Build prep
	- Ensure `sante plus ayitit.html` is in project root.
	- If you have static assets, place them in `public/` or adjust paths.

2. Create repo and push
	- `git init` (if needed)
	- `git add .` and `git commit -m "init"`
	- Push to GitHub/GitLab/Bitbucket.

3. Netlify setup
	- Go to https://app.netlify.com, login, and click "New site from Git".
	- Connect your repo.
	- Set deploy settings:
	  - Build command: (empty for plain HTML site)
	  - Publish directory: `.` (or `public` if files moved)
	- Click deploy.

4. Custom domain
	- In site settings > Domain management > Add custom domain: `santeplusayiti.org`.
	- Set DNS records at your domain provider:
	  - `A` to Netlify load balancer IPs or use `CNAME` for www.
	- Enable HTTPS (Netlify offers free cert).

5. API backend (optional)
	- Your Node API (`server.js`) cannot run on static Netlify without functions.
	- For full backend, deploy to Render/Heroku/Render, then update frontend endpoints to that URL.

