import fs from 'fs';
import axios from 'axios';
import OpenAI from 'openai';
import sgMail from '@sendgrid/mail';
import twilio from 'twilio';
import cron from 'node-cron';

// Load leads database
let leads = [];
try {
  const raw = fs.readFileSync('./leads-database.json', 'utf-8');
  leads = JSON.parse(raw);
} catch (err) {
  console.warn('leads-database.json not found, starting empty', err.message);
  leads = [];
}

// APIs
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const twClient = twilio(process.env.TWILIO_SID, process.env.TWILIO_TOKEN);
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

// Search for leads using Google Custom Search API (requires API key)
async function searchLeads() {
  const query = 'hôpitaux cliniques médecins Haiti';
  const apiKey = process.env.GOOGLE_API_KEY;
  const cx = process.env.GOOGLE_CX; // Custom Search Engine ID
  const url = `https://www.googleapis.com/customsearch/v1?key=${apiKey}&cx=${cx}&q=${encodeURIComponent(query)}&num=10`;

  try {
    const response = await axios.get(url);
    const results = response.data.items || [];
    const newLeads = results.map(item => ({
      name: item.title,
      type: item.title.includes('Hôpital') ? 'hospital' : item.title.includes('Clinique') ? 'clinic' : 'doctor',
      location: 'Haiti', // Assume Haiti, parse if possible
      contact: item.link, // Website link
      email: null, // Extract if possible
      phone: null,
      status: 'pending'
    }));
    leads.push(...newLeads);
    fs.writeFileSync('./leads-database.json', JSON.stringify(leads, null, 2));
    return newLeads.length;
  } catch (err) {
    console.error('Search failed', err.message);
    return 0;
  }
}

// Generate outreach message
async function generateMessage() {
  const prompt = `
Generate a professional partnership outreach message in French and Haitian Creole for SantePlus health insurance to hospitals/clinics/doctors in Haiti.
Keep under 200 chars total.
`;
  const response = await openai.responses.create({
    model: 'gpt-4o-mini',
    input: prompt,
    max_tokens: 100,
  });
  const text = response.output_text || response.output[0]?.content?.[0]?.text;
  return text?.trim() || 'Bonjour, nous sommes SantePlus, intéressés par un partenariat.';
}

// Send outreach (simulate, do not spam)
async function sendOutreach(lead) {
  // Email
  if (lead.email) {
    try {
      await sgMail.send({
        to: lead.email,
        from: process.env.SENDGRID_FROM,
        subject: 'Partenariat SantePlus - Assurance Santé',
        html: `<p>${await generateMessage()}</p>`,
      });
      console.log('Email sent to', lead.email);
    } catch (err) {
      console.error('Email failed', lead.email, err.message);
    }
  }

  // WhatsApp (if phone)
  if (lead.phone) {
    try {
      await twClient.messages.create({
        body: await generateMessage(),
        from: `whatsapp:${process.env.TWILIO_WHATSAPP_FROM}`,
        to: `whatsapp:${lead.phone}`,
      });
      console.log('WhatsApp sent to', lead.phone);
    } catch (err) {
      console.error('WhatsApp failed', lead.phone, err.message);
    }
  }

  lead.status = 'contacted';
  fs.writeFileSync('./leads-database.json', JSON.stringify(leads, null, 2));
}

// Daily report
function generateReport() {
  const contacted = leads.filter(l => l.status === 'contacted').length;
  const pending = leads.filter(l => l.status === 'pending').length;
  const report = `
Daily Report - SantePlus Business Development
- Leads found: ${leads.length}
- Contacted: ${contacted}
- Pending: ${pending}
- Responses: 0 (manual check required)
`;
  console.log(report);
  fs.writeFileSync('./daily-report.txt', report);
}

// Main daily task
async function runBusinessDevelopment() {
  try {
    const found = await searchLeads();
    console.log(`Found ${found} new leads`);

    // Send to up to 5 new leads per day
    const toContact = leads.filter(l => l.status === 'pending').slice(0, 5);
    for (const lead of toContact) {
      await sendOutreach(lead);
    }

    generateReport();
    console.log('Business development cycle completed');
  } catch (err) {
    console.error('BD cycle failed', err);
  }
}

// Schedule daily at 9:00 AM Haiti time
cron.schedule('0 9 * * *', () => {
  runBusinessDevelopment();
}, {
  timezone: 'America/New_York',
});

// Run once on start
runBusinessDevelopment();
