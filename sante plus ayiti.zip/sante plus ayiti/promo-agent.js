import fs from 'fs';
import OpenAI from 'openai';
import twilio from 'twilio';
import sgMail from '@sendgrid/mail';
import cron from 'node-cron';

// Load contact list from JSON file or fallback.
let leads = [];
try {
  const raw = fs.readFileSync('./lead-list.json', 'utf-8');
  leads = JSON.parse(raw);
} catch (err) {
  console.warn('lead-list.json not found, using sample static leads', err.message);
  leads = [
    { name: 'Katherine', phone: '+14076139643', email: 'katherine@example.com' },
    { name: 'Jean', phone: '+50912345678', email: 'jean@example.com' },
  ];
}

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const twClient = twilio(process.env.TWILIO_SID, process.env.TWILIO_TOKEN);
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

async function generatePromotion() {
  const prompt = `
You are a marketing copywriter for a Haitian health insurance service.
Write one short SMS + WhatsApp promotion in Haitian Creole + French (max 160 chars),
mention website https://santeplusayiti.org, plan from 500 HTG, and call +1 407-613-9643.
`;

  const response = await openai.responses.create({
    model: 'gpt-4o-mini',
    input: prompt,
    max_tokens: 120,
  });

  const text = response.output_text || response.output?.[0]?.content?.[0]?.text;
  return text?.trim() ||
    'Jwenn asirans sante nivo #1 sou santeplusayiti.org. 500 HTG/mwa, rele +1 407-613-9643 pou menm jan.';
}

async function sendOffers(message) {
  for (const lead of leads) {
    // SMS
    try {
      await twClient.messages.create({
        body: message,
        from: process.env.TWILIO_PHONE,
        to: lead.phone,
      });
      console.log('SMS sent', lead.phone);
    } catch (err) {
      console.error('SMS failed', lead.phone, err.message);
    }

    // WhatsApp
    try {
      await twClient.messages.create({
        body: message,
        from: `whatsapp:${process.env.TWILIO_WHATSAPP_FROM}`,
        to: `whatsapp:${lead.phone}`,
      });
      console.log('WhatsApp sent', lead.phone);
    } catch (err) {
      console.error('WhatsApp failed', lead.phone, err.message);
    }

    // Email
    try {
      await sgMail.send({
        to: lead.email,
        from: process.env.SENDGRID_FROM,
        subject: 'Promo SantéPlus Ayiti: Asirans kòmanse 500 HTG',
        html: `<p>${message}</p><p>https://santeplusayiti.org</p>`,
      });
      console.log('Email sent', lead.email);
    } catch (err) {
      console.error('Email failed', lead.email, err.message);
    }
  }
}

async function runMorningPromotion() {
  try {
    const message = await generatePromotion();
    console.log('[promo-agent] message:', message);
    await sendOffers(message);
    console.log('[promo-agent] Completed at', new Date().toISOString());
  } catch (err) {
    console.error('[promo-agent] Failed', err);
  }
}

// Run once immediately
runMorningPromotion();

// Schedule daily at 08:00 Haiti time (America/New_York offset from DST)
cron.schedule('0 8 * * *', () => {
  runMorningPromotion();
}, {
  timezone: 'America/New_York',
});
